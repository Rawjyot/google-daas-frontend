export const useGetLocalStorage = (name) => {
  return localStorage.getItem(name);
};
