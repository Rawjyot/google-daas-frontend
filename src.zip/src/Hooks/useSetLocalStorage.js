export const useSetLocalStorage = (name, value) => {
  localStorage.setItem(name, value);
};
