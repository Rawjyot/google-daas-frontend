[
  {
    id: 1,
    phone: { 1: "+91-677-4410427" },
    age: 49,
    date_of_birth: "1995-11-17T00:08:59.890Z",
    date_of_admission: "2011-10-17T00:40:01.399Z",
    firstName: "Adhiraj",
    middleName: "kumar",
    lastName: "singh",
    subRows: [
      {
        age: 33,
        date_of_birth: "1970-01-01T00:00:01.995Z",
        date_of_admission: "1970-01-01T00:00:02.016Z",
        firstName: "Ravi",
        middleName: "Charlie",
        lastName: "Kaul",
        phone: { 1: "+918270548665" },
        subRows: [
          {
            age: 78,
            date_of_birth: "1970-01-01T00:00:01.998Z",
            date_of_admission: "1970-01-01T00:00:02.014Z",
            firstName: "Dinakar",
            middleName: "kumar",
            lastName: "Gill",
            phone: { 1: "+917585820649" },
          },
          {
            age: 39,
            date_of_birth: "1970-01-01T00:00:01.997Z",
            date_of_admission: "1970-01-01T00:00:02.018Z",
            firstName: "Garud",
            middleName: "kumar",
            lastName: "Khanna",
            phone: { 1: "+91708-683-0555" },
          },
          {
            age: 59,
            date_of_birth: "1970-01-01T00:00:01.995Z",
            date_of_admission: "1970-01-01T00:00:02.014Z",
            firstName: "aditya",
            middleName: "kumar",
            lastName: "Trivedi",
            phone: { 1: "+91940-840-0928" },
          },
          {
            age: 56,
            date_of_birth: "1970-01-01T00:00:01.998Z",
            date_of_admission: "1970-01-01T00:00:02.017Z",
            firstName: "Devasree",
            middleName: "kumar",
            lastName: "upadhyay",
            phone: { 1: "+917692676238" },
          },
        ],
      },
      {
        age: 31,
        date_of_birth: "1970-01-01T00:00:02.000Z",
        date_of_admission: "1970-01-01T00:00:02.007Z",
        firstName: "Vasant",
        middleName: "kumar",
        lastName: "Ahluwalia",
        phone: { 1: "+919952877228" },
        subRows: [
          {
            age: 5,
            date_of_birth: "1970-01-01T00:00:01.994Z",
            date_of_admission: "1970-01-01T00:00:02.013Z",
            firstName: "vishwas",
            middleName: "kumar",
            lastName: "Bhardwaj",
            phone: { 1: "+916862368194" },
          },
          {
            age: 41,
            date_of_birth: "1970-01-01T00:00:01.993Z",
            date_of_admission: "1970-01-01T00:00:02.008Z",
            firstName: "Ambar",
            middleName: "kumar",
            lastName: "maurya",
            phone: { 1: "+916860577015" },
          },
          {
            age: 31,
            date_of_birth: "1970-01-01T00:00:02.001Z",
            date_of_admission: "1970-01-01T00:00:02.007Z",
            firstName: "aman",
            middleName: "kumar",
            lastName: "Sharma",
            phone: { 1: "+91688-996-1777" },
          },
          {
            age: 36,
            date_of_birth: "1970-01-01T00:00:02.000Z",
            date_of_admission: "1970-01-01T00:00:02.015Z",
            firstName: "Rajan",
            middleName: "kumar",
            lastName: "Verma",
            phone: { 1: "+91935-446-2930" },
          },
        ],
      },
      {
        age: 30,
        date_of_birth: "1970-01-01T00:00:01.996Z",
        date_of_admission: "1970-01-01T00:00:02.012Z",
        firstName: "Satyendra",
        middleName: "kumar",
        lastName: "Bharadwaj",
        phone: { 1: "+918773173455" },
        subRows: [
          {
            age: 16,
            date_of_birth: "1970-01-01T00:00:01.995Z",
            date_of_admission: "1970-01-01T00:00:02.013Z",
            firstName: "Tapan",
            middleName: "kumar",
            lastName: "Shah",
            phone: { 1: "+91-798-8019068" },
          },
          {
            age: 26,
            date_of_birth: "1970-01-01T00:00:01.993Z",
            date_of_admission: "1970-01-01T00:00:02.006Z",
            firstName: "Bhagwanti",
            middleName: "devi",
            lastName: "Nayar",
            phone: { 1: "+918756630538" },
          },
          {
            age: 16,
            date_of_birth: "1970-01-01T00:00:02.000Z",
            date_of_admission: "1970-01-01T00:00:02.018Z",
            firstName: "Anant",
            middleName: "kumar",
            lastName: "Nair",
            phone: { 1: "+91916-452-3270" },
          },
          {
            age: 5,
            date_of_birth: "1970-01-01T00:00:01.992Z",
            date_of_admission: "1970-01-01T00:00:02.016Z",
            firstName: "Vijay",
            middleName: "kumar",
            lastName: "sharma",
            phone: { 1: "+91990-027-7100" },
          },
        ],
      },
    ],
  },
];

[
  {
    badData: 0,
    contacts: 28,
    disqualified: 0,
    followups: 0,
    id: 1,
    nominatedAccount: 8,
    opportunities: 5,
    profileAccount: 4,
    region: "Greater China",
    subRows: [
      {
        badData: 0,
        contacts: 4,
        disqualified: 0,
        followups: 0,
        id: 1,
        nominatedAccount: 2,
        opportunities: 0,
        partner: "Mohit3",
        profileAccount: 0,
        subRows: [
          {
            badData: 0,
            contacts: 2,
            disqualified: 0,
            followups: 0,
            nominatedAccounts: 1,
            opportunities: 0,
            profiledAccounts: 0,
            region: "Greater China",
          },
          {
            badData: 0,
            contacts: 2,
            disqualified: 0,
            followups: 0,
            nominatedAccounts: 1,
            opportunities: 0,
            profiledAccounts: 0,
            region: "Greater China",
          },
        ],
      },
      {
        badData: 0,
        contacts: 6,
        disqualified: 0,
        followups: 0,
        id: 1,
        nominatedAccount: 1,
        opportunities: 1,
        partner: "Mohit1",
        profileAccount: 1,
        subRows: [
          {
            badData: 0,
            contacts: 6,
            disqualified: 0,
            followups: 0,
            nominatedAccounts: 1,
            opportunities: 1,
            profiledAccounts: 1,
            region: "Greater China",
          },
        ],
      },
      {
        badData: 0,
        contacts: 9,
        disqualified: 0,
        followups: 0,
        id: 1,
        nominatedAccount: 2,
        opportunities: 1,
        partner: "Mohit2",
        profileAccount: 1,
        subRows: [
          {
            badData: 0,
            contacts: 2,
            disqualified: 0,
            followups: 0,
            nominatedAccounts: 1,
            opportunities: 0,
            profiledAccounts: 0,
            region: "Greater China",
          },
          {
            badData: 0,
            contacts: 7,
            disqualified: 0,
            followups: 0,
            nominatedAccounts: 1,
            opportunities: 1,
            profiledAccounts: 1,
            region: "Greater China",
          },
        ],
      },
    ],
  },
  {
    badData: 0,
    contacts: 28,
    disqualified: 0,
    followups: 0,
    id: 1,
    nominatedAccount: 8,
    opportunities: 5,
    profileAccount: 4,
    region: "India",
    subRows: [
      {
        badData: 0,
        contacts: 9,
        disqualified: 0,
        followups: 0,
        id: 1,
        nominatedAccount: 3,
        opportunities: 3,
        partner: "Mohit",
        profileAccount: 2,
        subRows: [
          {
            badData: 0,
            contacts: 3,
            disqualified: 0,
            followups: 0,
            nominatedAccounts: 1,
            opportunities: 1,
            profiledAccounts: 0,
            region: "India",
          },
          {
            badData: 0,
            contacts: 4,
            disqualified: 0,
            followups: 0,
            nominatedAccounts: 1,
            opportunities: 1,
            profiledAccounts: 1,
            region: "India",
          },
          {
            badData: 0,
            contacts: 2,
            disqualified: 0,
            followups: 0,
            nominatedAccounts: 1,
            opportunities: 1,
            profiledAccounts: 1,
            region: "India",
          },
        ],
      },
    ],
  },
];
// [
// [
//   {
//       "updatedStatus": "Touched",
//       "previousStatus": "Bad data ",
//       "modifiedDate": "2024-01-19T10:15:13.8578037",
//       "previousModifiedDate": "2024-01-19T10:14:53.1110003",
//       "name": "Malathy Ar",
//   },
// ]

// filters [{
//"option1" : option1,
//"option2" : option2,
//"option3" : option3,
//"option4" : option4,
//"option5" : option5,
// }]

// status Update for body from frontend
// {
//   status:"status",
//   remark:"entered Remark"
// }

// {
//   "id": 1,
//   "phone": { "1": "+91-677-4410427" },
//   "age": 66,
//   "date_of_birth": "1995-11-17T00:08:59.890Z",
//   "date_of_admission": "2011-10-17T00:40:01.399Z",
//   "firstName": "Adhiraj",
//   "middleName": "kumar",
//   "lastName": "singh",
//   "subRows": [
//     {
//       "age": 2,
//       "date_of_birth": "1970-01-01T00:00:01.995Z",
//       "date_of_admission": "1970-01-01T00:00:02.016Z",
//       "firstName": "Ravi",
//       "middleName": "Charlie",
//       "lastName": "Kaul",
//       "phone": { "1": "+918270548665" },
//       "subRows": [
//         {
//           "age": 55,
//           "date_of_birth": "1970-01-01T00:00:01.998Z",
//           "date_of_admission": "1970-01-01T00:00:02.014Z",
//           "firstName": "Dinakar",
//           "middleName": "kumar",
//           "lastName": "Gill",
//           "phone": { "1": "+917585820649" }
//         },
//         {
//           "age": 23,
//           "date_of_birth": "1970-01-01T00:00:01.997Z",
//           "date_of_admission": "1970-01-01T00:00:02.018Z",
//           "firstName": "Garud",
//           "middleName": "kumar",
//           "lastName": "Khanna",
//           "phone": { "1": "+91708-683-0555" }
//         },
//         {
//           "age": 51,
//           "date_of_birth": "1970-01-01T00:00:01.995Z",
//           "date_of_admission": "1970-01-01T00:00:02.014Z",
//           "firstName": "aditya",
//           "middleName": "kumar",
//           "lastName": "Trivedi",
//           "phone": { "1": "+91940-840-0928" }
//         },
//         {
//           "age": 85,
//           "date_of_birth": "1970-01-01T00:00:01.998Z",
//           "date_of_admission": "1970-01-01T00:00:02.017Z",
//           "firstName": "Devasree",
//           "middleName": "kumar",
//           "lastName": "upadhyay",
//           "phone": { "1": "+917692676238" }
//         }
//       ]
//     },
//     {
//       "age": 71,
//       "date_of_birth": "1970-01-01T00:00:02.000Z",
//       "date_of_admission": "1970-01-01T00:00:02.007Z",
//       "firstName": "Vasant",
//       "middleName": "kumar",
//       "lastName": "Ahluwalia",
//       "phone": { "1": "+919952877228" },
//       "subRows": [
//         {
//           "age": 89,
//           "date_of_birth": "1970-01-01T00:00:01.994Z",
//           "date_of_admission": "1970-01-01T00:00:02.013Z",
//           "firstName": "vishwas",
//           "middleName": "kumar",
//           "lastName": "Bhardwaj",
//           "phone": { "1": "+916862368194" }
//         },
//         {
//           "age": 1,
//           "date_of_birth": "1970-01-01T00:00:01.993Z",
//           "date_of_admission": "1970-01-01T00:00:02.008Z",
//           "firstName": "Ambar",
//           "middleName": "kumar",
//           "lastName": "maurya",
//           "phone": { "1": "+916860577015" }
//         },
//         {
//           "age": 68,
//           "date_of_birth": "1970-01-01T00:00:02.001Z",
//           "date_of_admission": "1970-01-01T00:00:02.007Z",
//           "firstName": "aman",
//           "middleName": "kumar",
//           "lastName": "Sharma",
//           "phone": { "1": "+91688-996-1777" }
//         },
//         {
//           "age": 20,
//           "date_of_birth": "1970-01-01T00:00:02.000Z",
//           "date_of_admission": "1970-01-01T00:00:02.015Z",
//           "firstName": "Rajan",
//           "middleName": "kumar",
//           "lastName": "Verma",
//           "phone": { "1": "+91935-446-2930" }
//         }
//       ]
//     },
//     {
//       "age": 64,
//       "date_of_birth": "1970-01-01T00:00:01.996Z",
//       "date_of_admission": "1970-01-01T00:00:02.012Z",
//       "firstName": "Satyendra",
//       "middleName": "kumar",
//       "lastName": "Bharadwaj",
//       "phone": { "1": "+918773173455" },
//       "subRows": [
//         {
//           "age": 95,
//           "date_of_birth": "1970-01-01T00:00:01.995Z",
//           "date_of_admission": "1970-01-01T00:00:02.013Z",
//           "firstName": "Tapan",
//           "middleName": "kumar",
//           "lastName": "Shah",
//           "phone": { "1": "+91-798-8019068" }
//         },
//         {
//           "age": 70,
//           "date_of_birth": "1970-01-01T00:00:01.993Z",
//           "date_of_admission": "1970-01-01T00:00:02.006Z",
//           "firstName": "Bhagwanti",
//           "middleName": "devi",
//           "lastName": "Nayar",
//           "phone": { "1": "+918756630538" }
// ]
//         },
//         {
//           "age": 51,
//           "date_of_birth": "1970-01-01T00:00:02.000Z",
//           "date_of_admission": "1970-01-01T00:00:02.018Z",
//           "firstName": "Anant",
//           "middleName": "kumar",
//           "lastName": "Nair",
//           "phone": { "1": "+91916-452-3270" }
//         },
//         {
//           "age": 22,
//           "date_of_birth": "1970-01-01T00:00:01.992Z",
//           "date_of_admission": "1970-01-01T00:00:02.016Z",
//           "firstName": "Vijay",
//           "middleName": "kumar",
//           "lastName": "sharma",
//           "phone": { "1": "+91990-027-7100" }
//         }
//       ]
//     }
//   ]
// },
// {
//   "id": 1,
//   "phone": { "1": "+91-677-4410427" },
//   "age": 76,
//   "date_of_birth": "1995-11-17T00:08:59.890Z",
//   "date_of_admission": "2011-10-17T00:40:01.399Z",
//   "firstName": "Adhiraj",
//   "middleName": "kumar",
//   "lastName": "singh",
//   "subRows": [
//     {
//       "age": 84,
//       "date_of_birth": "1970-01-01T00:00:01.995Z",
//       "date_of_admission": "1970-01-01T00:00:02.016Z",
//       "firstName": "Ravi",
//       "middleName": "Charlie",
//       "lastName": "Kaul",
//       "phone": { "1": "+918270548665" },
//       "subRows": [
//         {
//           "age": 16,
//           "date_of_birth": "1970-01-01T00:00:01.998Z",
//           "date_of_admission": "1970-01-01T00:00:02.014Z",
//           "firstName": "Dinakar",
//           "middleName": "kumar",
//           "lastName": "Gill",
//           "phone": { "1": "+917585820649" }
//         },
//         {
//           "age": 61,
//           "date_of_birth": "1970-01-01T00:00:01.997Z",
//           "date_of_admission": "1970-01-01T00:00:02.018Z",
//           "firstName": "Garud",
//           "middleName": "kumar",
//           "lastName": "Khanna",
//           "phone": { "1": "+91708-683-0555" }
//         },
//         {
//           "age": 74,
//           "date_of_birth": "1970-01-01T00:00:01.995Z",
//           "date_of_admission": "1970-01-01T00:00:02.014Z",
//           "firstName": "aditya",
//           "middleName": "kumar",
//           "lastName": "Trivedi",
//           "phone": { "1": "+91940-840-0928" }
//         },
//         {
//           "age": 47,
//           "date_of_birth": "1970-01-01T00:00:01.998Z",
//           "date_of_admission": "1970-01-01T00:00:02.017Z",
//           "firstName": "Devasree",
//           "middleName": "kumar",
//           "lastName": "upadhyay",
//           "phone": { "1": "+917692676238" }
//         }
//       ]
//     },
//     {
//       "age": 57,
//       "date_of_birth": "1970-01-01T00:00:02.000Z",
//       "date_of_admission": "1970-01-01T00:00:02.007Z",
//       "firstName": "Vasant",
//       "middleName": "kumar",
//       "lastName": "Ahluwalia",
//       "phone": { "1": "+919952877228" },
//       "subRows": [
//         {
//           "age": 60,
//           "date_of_birth": "1970-01-01T00:00:01.994Z",
//           "date_of_admission": "1970-01-01T00:00:02.013Z",
//           "firstName": "vishwas",
//           "middleName": "kumar",
//           "lastName": "Bhardwaj",
//           "phone": { "1": "+916862368194" }
//         },
//         {
//           "age": 68,
//           "date_of_birth": "1970-01-01T00:00:01.993Z",
//           "date_of_admission": "1970-01-01T00:00:02.008Z",
//           "firstName": "Ambar",
//           "middleName": "kumar",
//           "lastName": "maurya",
//           "phone": { "1": "+916860577015" }
//         },
//         {
//           "age": 84,
//           "date_of_birth": "1970-01-01T00:00:02.001Z",
//           "date_of_admission": "1970-01-01T00:00:02.007Z",
//           "firstName": "aman",
//           "middleName": "kumar",
//           "lastName": "Sharma",
//           "phone": { "1": "+91688-996-1777" }
//         },
//         {
//           "age": 43,
//           "date_of_birth": "1970-01-01T00:00:02.000Z",
//           "date_of_admission": "1970-01-01T00:00:02.015Z",
//           "firstName": "Rajan",
//           "middleName": "kumar",
//           "lastName": "Verma",
//           "phone": { "1": "+91935-446-2930" }
//         }
//       ]
//     },
//     {
//       "age": 1,
//       "date_of_birth": "1970-01-01T00:00:01.996Z",
//       "date_of_admission": "1970-01-01T00:00:02.012Z",
//       "firstName": "Satyendra",
//       "middleName": "kumar",
//       "lastName": "Bharadwaj",
//       "phone": { "1": "+918773173455" },
//       "subRows": [
//         {
//           "age": 71,
//           "date_of_birth": "1970-01-01T00:00:01.995Z",
//           "date_of_admission": "1970-01-01T00:00:02.013Z",
//           "firstName": "Tapan",
//           "middleName": "kumar",
//           "lastName": "Shah",
//           "phone": { "1": "+91-798-8019068" }
//         },
//         {
//           "age": 35,
//           "date_of_birth": "1970-01-01T00:00:01.993Z",
//           "date_of_admission": "1970-01-01T00:00:02.006Z",
//           "firstName": "Bhagwanti",
//           "middleName": "devi",
//           "lastName": "Nayar",
//           "phone": { "1": "+918756630538" }
//         },
//         {
//           "age": 78,
//           "date_of_birth": "1970-01-01T00:00:02.000Z",
//           "date_of_admission": "1970-01-01T00:00:02.018Z",
//           "firstName": "Anant",
//           "middleName": "kumar",
//           "lastName": "Nair",
//           "phone": { "1": "+91916-452-3270" }
//         },
//         {
//           "age": 26,
//           "date_of_birth": "1970-01-01T00:00:01.992Z",
//           "date_of_admission": "1970-01-01T00:00:02.016Z",
//           "firstName": "Vijay",
//           "middleName": "kumar",
//           "lastName": "sharma",
//           "phone": { "1": "+91990-027-7100" }
//         }
//       ]
//     }
//   ]
// }
// ]

// [
//   {
//     "id": 1,
//     "badData": 23,
//     "Contacts": 49,
//     "Opportunities": 234,
//     "Followups": 3543,
//     "Regions": "all",
//     "nominatedAccount": 234,
//     "profileAccount": 34,
//     "Disqualified": 47,
//     "subRows": [
//       {
//         "id": 1,
//         "badData": 23,
//         "Contacts": 49,
//         "Opportunities": 234,
//         "Followups": 3543,
//         "Regions": "INDIA",
//         "nominatedAccount": 234,
//         "profileAccount": 34,
//         "Disqualified": 47,
//         "subRows": [
//           {
//             "id": 1,
//             "badData": 23,
//             "Contacts": 49,
//             "Opportunities": 234,
//             "Followups": 3543,
//             "Regions": "User 1",
//             "nominatedAccount": 234,
//             "profileAccount": 34,
//             "Disqualified": 47
//           },
//           {
//             "id": 1,
//             "badData": 23,
//             "Contacts": 49,
//             "Opportunities": 234,
//             "Followups": 3543,
//             "Regions": "User 2",
//             "nominatedAccount": 234,
//             "profileAccount": 34,
//             "Disqualified": 47
//           }
//         ]
//       },
//       {
//         "id": 1,
//         "badData": 23,
//         "Contacts": 49,
//         "Opportunities": 234,
//         "Followups": 3543,
//         "Regions": "SEA",
//         "nominatedAccount": 234,
//         "profileAccount": 34,
//         "Disqualified": 47,
//         "subRows": [
//           {
//             "id": 1,
//             "badData": 23,
//             "Contacts": 49,
//             "Opportunities": 234,
//             "Followups": 3543,
//             "Regions": "User 1",
//             "nominatedAccount": 234,
//             "profileAccount": 34,
//             "Disqualified": 47
//           },
//           {
//             "id": 1,
//             "badData": 23,
//             "Contacts": 49,
//             "Opportunities": 234,
//             "Followups": 3543,
//             "Regions": "User 2",
//             "nominatedAccount": 234,
//             "profileAccount": 34,
//             "Disqualified": 47
//           }
//         ]
//       }
//     ]
//   }
// ]

//  [
//   {
//     accountName: "bhadra international india limited",
//     size: "501-1000 employees",
//     industry: "Logistics & Transportation",
//     revenue: "0-1M",
//     boardlineNumber: "1,140,000,000.00",
//     city: "New Delhi",
//     state: "Delhi",
//     country: "India",
//     noOfContacts: 2,
//     newContacts: 0,
//     status: "Opportunities",
//     assignToName: "Mohit",

//     assignToUser: null,
//     id: null,
//     name: null
//   },
//   {
//     accountName: "bhadra international india limited",
//     size: "501-1000 employees",
//     industry: "Logistics & Transportation",
//     revenue: "0-1M",
//     boardlineNumber: "1,140,000,000.00",
//     city: "New Delhi",
//     state: "Delhi",
//     country: "India",
//     noOfContacts: 2,
//     newContacts: 0,
//     status: "Opportunities",
//     assignToName: "Mohit1",
//     assignToUser: null,
//     id: null,
//     name: null
//   },
//   {
//     accountName: "bhadra international india limited",
//     size: "501-1000 employees",
//     industry: "Logistics & Transportation",
//     revenue: "0-1M",
//     boardlineNumber: "1,140,000,000.00",
//     city: "New Delhi",
//     state: "Delhi",
//     country: "India",
//     noOfContacts: 2,
//     newContacts: 0,
//     status: "Opportunities",
//     assignToName: "Mohit3",
//     assignToUser: null,
//     id: null,
//     name: null
//   }
// ]
